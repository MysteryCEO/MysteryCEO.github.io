"use client"

import { useEffect, useRef, useState } from "react"
import { motion, AnimatePresence, useScroll, useTransform, useMotionValueEvent } from "framer-motion"

export default function Home() {
  const [isLoaded, setIsLoaded] = useState(false)
  const [activeTestimonial, setActiveTestimonial] = useState(0)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [showBackToTop, setShowBackToTop] = useState(false)
  const [activePage, setActivePage] = useState("home")
  const [scrollProgress, setScrollProgress] = useState(0)
  const [isNavScrolled, setIsNavScrolled] = useState(false)

  const { scrollYProgress } = useScroll()
  const mainRef = useRef<HTMLDivElement>(null)

  // Track scroll progress for progress bar
  useMotionValueEvent(scrollYProgress, "change", (latest) => {
    setScrollProgress(latest)

    if (latest > 0.05) {
      setIsNavScrolled(true)
      if (latest > 0.2) {
        setShowBackToTop(true)
      } else {
        setShowBackToTop(false)
      }
    } else {
      setIsNavScrolled(false)
    }
  })

  // Testimonial auto-rotation
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev === 3 ? 0 : prev + 1))
    }, 6000)

    return () => clearInterval(interval)
  }, [])

  // Initial load animation
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoaded(true)
    }, 500)

    return () => clearTimeout(timer)
  }, [])

  // Handle page navigation
  const navigateTo = (page: string) => {
    setActivePage(page)
    setIsMenuOpen(false)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  // Scroll to section
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      const navHeight = 80
      const elementPosition = element.getBoundingClientRect().top + window.scrollY
      const offsetPosition = elementPosition - navHeight

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      })
    }
    setIsMenuOpen(false)
  }

  // Render active page content
  const renderPageContent = () => {
    switch (activePage) {
      case "privacy":
        return <PrivacyPolicy onBack={() => setActivePage("home")} />
      case "terms":
        return <TermsOfService onBack={() => setActivePage("home")} />
      case "contact":
        return <Contact onBack={() => setActivePage("home")} />
      default:
        return (
          <HomePage
            activeTestimonial={activeTestimonial}
            setActiveTestimonial={setActiveTestimonial}
            scrollToSection={scrollToSection}
          />
        )
    }
  }

  return (
    <div className="relative overflow-x-hidden" ref={mainRef}>
      {/* Initial loading animation */}
      <AnimatePresence>
        {!isLoaded && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 1.2, opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="text-white text-4xl font-serif"
            >
              7 DARK ARTS
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Progress bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-accent z-50"
        style={{ scaleX: scrollProgress, transformOrigin: "0%" }}
      />

      {/* Navigation */}
      <motion.nav
        className="fixed top-0 left-0 w-full z-40 py-5"
        initial={{ y: -100 }}
        animate={{
          y: 0,
          backgroundColor: isNavScrolled ? "rgba(0, 0, 0, 0.98)" : "rgba(0, 0, 0, 0.95)",
          padding: isNavScrolled ? "12px 0" : "20px 0",
        }}
        transition={{ duration: 0.3 }}
      >
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <motion.a
            href="#"
            className="font-serif text-white text-xl font-bold relative"
            onClick={(e) => {
              e.preventDefault()
              navigateTo("home")
            }}
            whileHover={{ color: "var(--accent-light)" }}
          >
            7 DARK ARTS
            <motion.span
              className="absolute bottom-0 left-0 h-px bg-accent"
              initial={{ width: 0 }}
              whileHover={{ width: "100%" }}
              transition={{ duration: 0.3 }}
            />
          </motion.a>

          <ul className="hidden md:flex space-x-10">
            {["about", "chapters", "testimonials", "offer"].map((item) => (
              <motion.li key={item}>
                <motion.a
                  href={`#${item}`}
                  className="text-white text-sm font-medium relative"
                  onClick={(e) => {
                    e.preventDefault()
                    scrollToSection(item)
                  }}
                  whileHover={{ color: "var(--accent-light)" }}
                >
                  {item.charAt(0).toUpperCase() + item.slice(1)}
                  <motion.span
                    className="absolute bottom-0 left-0 h-px bg-accent"
                    initial={{ width: 0 }}
                    whileHover={{ width: "100%" }}
                    transition={{ duration: 0.3 }}
                  />
                </motion.a>
              </motion.li>
            ))}
          </ul>

          <motion.button
            className="md:hidden relative w-8 h-6 flex flex-col justify-between z-50"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            <motion.span
              className="w-full h-0.5 bg-white"
              animate={{
                rotate: isMenuOpen ? 45 : 0,
                y: isMenuOpen ? 9 : 0,
              }}
            />
            <motion.span className="w-full h-0.5 bg-white" animate={{ opacity: isMenuOpen ? 0 : 1 }} />
            <motion.span
              className="w-full h-0.5 bg-white"
              animate={{
                rotate: isMenuOpen ? -45 : 0,
                y: isMenuOpen ? -9 : 0,
              }}
            />
          </motion.button>
        </div>
      </motion.nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            className="fixed inset-0 bg-black bg-opacity-95 z-30 flex items-center justify-center"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          >
            <motion.ul
              className="flex flex-col items-center space-y-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, staggerChildren: 0.1 }}
            >
              {["about", "chapters", "testimonials", "offer"].map((item, index) => (
                <motion.li
                  key={item}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                >
                  <motion.a
                    href={`#${item}`}
                    className="text-white text-2xl font-medium"
                    onClick={(e) => {
                      e.preventDefault()
                      scrollToSection(item)
                    }}
                    whileHover={{ color: "var(--accent-light)", x: 5 }}
                  >
                    {item.charAt(0).toUpperCase() + item.slice(1)}
                  </motion.a>
                </motion.li>
              ))}
            </motion.ul>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main content */}
      <main>{renderPageContent()}</main>

      {/* Footer */}
      <footer className="bg-black text-white py-20 relative">
        <motion.div
          className="absolute top-0 left-0 w-full h-px"
          style={{
            background: "linear-gradient(90deg, transparent, var(--accent), transparent)",
          }}
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.5 }}
        />

        <div className="max-w-7xl mx-auto px-6 text-center">
          <motion.div
            className="font-serif text-2xl mb-5"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            7 DARK ARTS
          </motion.div>

          <motion.p
            className="max-w-xl mx-auto mb-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            The 7 Dark Arts of Seduction is a psychological study, not a guide to manipulation. Use these insights
            responsibly.
          </motion.p>

          <motion.ul
            className="flex flex-wrap justify-center space-x-6 mb-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <li>
              <motion.a
                href="#"
                className="text-gray-400 hover:text-accent-light relative"
                onClick={(e) => {
                  e.preventDefault()
                  navigateTo("privacy")
                }}
                whileHover={{ color: "var(--accent-light)" }}
              >
                Privacy Policy
                <motion.span
                  className="absolute bottom-0 left-0 h-px bg-accent-light"
                  initial={{ width: 0 }}
                  whileHover={{ width: "100%" }}
                  transition={{ duration: 0.3 }}
                />
              </motion.a>
            </li>
            <li>
              <motion.a
                href="#"
                className="text-gray-400 hover:text-accent-light relative"
                onClick={(e) => {
                  e.preventDefault()
                  navigateTo("terms")
                }}
                whileHover={{ color: "var(--accent-light)" }}
              >
                Terms
                <motion.span
                  className="absolute bottom-0 left-0 h-px bg-accent-light"
                  initial={{ width: 0 }}
                  whileHover={{ width: "100%" }}
                  transition={{ duration: 0.3 }}
                />
              </motion.a>
            </li>
            <li>
              <motion.a
                href="#"
                className="text-gray-400 hover:text-accent-light relative"
                onClick={(e) => {
                  e.preventDefault()
                  navigateTo("contact")
                }}
                whileHover={{ color: "var(--accent-light)" }}
              >
                Contact
                <motion.span
                  className="absolute bottom-0 left-0 h-px bg-accent-light"
                  initial={{ width: 0 }}
                  whileHover={{ width: "100%" }}
                  transition={{ duration: 0.3 }}
                />
              </motion.a>
            </li>
          </motion.ul>

          <motion.p
            className="text-sm text-gray-500"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            © 2023 The 7 Dark Arts of Seduction. All rights reserved.
          </motion.p>
        </div>
      </footer>

      {/* Back to top button */}
      <AnimatePresence>
        {showBackToTop && (
          <motion.button
            className="fixed bottom-8 right-8 w-12 h-12 bg-black border border-accent rounded-full flex items-center justify-center z-20"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            whileHover={{ y: -5, backgroundColor: "var(--accent)" }}
            transition={{ duration: 0.3 }}
            aria-label="Back to top"
          >
            <svg width="10" height="10" viewBox="0 0 10 10" className="text-white">
              <path
                d="M5 1L1 5M5 1L9 5M5 1V9"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  )
}

// Home Page Component
function HomePage({
  activeTestimonial,
  setActiveTestimonial,
  scrollToSection,
}: {
  activeTestimonial: number
  setActiveTestimonial: (index: number) => void
  scrollToSection: (id: string) => void
}) {
  const { scrollYProgress } = useScroll()
  const headerY = useTransform(scrollYProgress, [0, 0.3], [0, 100])
  const headerOpacity = useTransform(scrollYProgress, [0, 0.3], [1, 0])

  return (
    <>
      {/* Header */}
      <motion.header
        className="relative text-white py-48 overflow-hidden"
        style={{
          background:
            "linear-gradient(to bottom, rgba(0, 0, 0, 0.9), rgba(0, 0, 0, 0.7)), url('https://images.unsplash.com/photo-1507842217343-583bb7270b66?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80') center/cover no-repeat",
        }}
      >
        <motion.div
          className="absolute inset-0"
          style={{
            background: "radial-gradient(circle at center, rgba(154, 140, 152, 0.2) 0%, transparent 70%)",
            y: headerY,
            opacity: headerOpacity,
          }}
        />

        <div className="max-w-7xl mx-auto px-6 text-center relative z-10">
          <motion.h1
            className="font-serif text-5xl md:text-6xl mb-8 leading-tight"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.8,
              delay: 0.3,
              ease: [0.22, 1, 0.36, 1],
            }}
          >
            The 7 Dark Arts of Seduction
          </motion.h1>

          <motion.p
            className="text-xl md:text-2xl max-w-3xl mx-auto text-gray-200"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.8,
              delay: 0.5,
              ease: [0.22, 1, 0.36, 1],
            }}
          >
            A psychological exploration of connection, influence, and human behavior
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.8,
              delay: 0.7,
              ease: [0.22, 1, 0.36, 1],
            }}
          >
            <FlameAnimation />
          </motion.div>
        </div>
      </motion.header>

      {/* About Section */}
      <section id="about" className="py-32 bg-white relative">
        <motion.div
          className="absolute top-0 left-0 w-full h-px"
          style={{
            background: "linear-gradient(90deg, transparent, var(--accent), transparent)",
          }}
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.5 }}
        />

        <div className="max-w-7xl mx-auto px-6 text-center">
          <motion.h2
            className="font-serif text-4xl mb-8 inline-block relative"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            The Psychology Behind Connection
            <motion.span
              className="absolute bottom-0 left-1/2 h-0.5 bg-accent"
              initial={{ width: "60px", x: "-50%" }}
              whileInView={{ width: "100px", x: "-50%" }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
            />
          </motion.h2>

          <motion.p
            className="text-xl max-w-3xl mx-auto mb-10 text-dark-gray"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            This book reveals the unconscious patterns that shape relationships and influence. Not tricks or
            manipulation—but fundamental truths about human nature.
          </motion.p>

          <motion.a
            href="#chapters"
            className="inline-block bg-black text-white px-10 py-4 font-semibold text-base tracking-wide border border-black relative overflow-hidden"
            onClick={(e) => {
              e.preventDefault()
              scrollToSection("chapters")
            }}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            whileHover={{ borderColor: "var(--accent)" }}
          >
            <motion.span
              className="absolute inset-0 bg-accent"
              initial={{ x: "-100%" }}
              whileHover={{ x: 0 }}
              transition={{ duration: 0.3 }}
              style={{ zIndex: -1 }}
            />
            Explore Chapters
          </motion.a>
        </div>
      </section>

      {/* Chapters Section */}
      <section id="chapters" className="py-32 bg-gray relative">
        <motion.div
          className="absolute inset-0"
          style={{
            background: "radial-gradient(circle at 70% 30%, rgba(154, 140, 152, 0.1) 0%, transparent 70%)",
          }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
        />

        <div className="max-w-7xl mx-auto px-6">
          <motion.h2
            className="text-center font-serif text-4xl mb-16 relative"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            What You'll Learn
            <motion.span
              className="absolute bottom-0 left-1/2 h-0.5 bg-accent"
              initial={{ width: "60px", x: "-50%" }}
              whileInView={{ width: "100px", x: "-50%" }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
            />
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {chapters.map((chapter, index) => (
              <ChapterCard key={index} chapter={chapter} index={index} />
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-32 bg-white relative">
        <motion.div
          className="absolute top-0 left-0 w-full h-px"
          style={{
            background: "linear-gradient(90deg, transparent, var(--accent), transparent)",
          }}
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.5 }}
        />

        <div className="max-w-7xl mx-auto px-6">
          <motion.h2
            className="text-center font-serif text-4xl mb-16 relative"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            Readers' Experiences
            <motion.span
              className="absolute bottom-0 left-1/2 h-0.5 bg-accent"
              initial={{ width: "60px", x: "-50%" }}
              whileInView={{ width: "100px", x: "-50%" }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
            />
          </motion.h2>

          <div className="max-w-4xl mx-auto relative">
            <div className="overflow-hidden">
              <motion.div
                className="flex"
                animate={{ x: `-${activeTestimonial * 100}%` }}
                transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              >
                {testimonials.map((testimonial, index) => (
                  <div key={index} className="min-w-full px-4">
                    <motion.div
                      className="bg-gray p-10 rounded relative"
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{
                        opacity: activeTestimonial === index ? 1 : 0.5,
                        scale: activeTestimonial === index ? 1 : 0.9,
                      }}
                      transition={{ duration: 0.5 }}
                    >
                      <div className="text-6xl font-serif text-accent opacity-20 absolute top-5 left-5">"</div>
                      <p className="text-lg italic mb-6 relative z-10">{testimonial.text}</p>
                      <div className="font-semibold text-accent-dark flex items-center">
                        <span className="w-5 h-px bg-accent mr-3"></span>
                        {testimonial.author}
                      </div>
                    </motion.div>
                  </div>
                ))}
              </motion.div>
            </div>

            <div className="flex justify-center mt-10 space-x-3">
              {testimonials.map((_, index) => (
                <motion.button
                  key={index}
                  className="w-3 h-3 rounded-full bg-gray"
                  onClick={() => setActiveTestimonial(index)}
                  animate={{
                    scale: activeTestimonial === index ? 1.3 : 1,
                    backgroundColor: activeTestimonial === index ? "var(--accent)" : "var(--gray)",
                  }}
                  whileHover={{ scale: 1.2 }}
                  transition={{ duration: 0.3 }}
                />
              ))}
            </div>

            <div className="flex justify-center mt-6 space-x-4">
              <motion.button
                className="w-10 h-10 rounded-full flex items-center justify-center"
                onClick={() => setActiveTestimonial((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1))}
                whileHover={{ backgroundColor: "rgba(154, 140, 152, 0.1)" }}
                transition={{ duration: 0.3 }}
              >
                <span className="w-2.5 h-2.5 border-t-2 border-r-2 border-accent transform rotate-[-135deg] translate-x-0.5"></span>
              </motion.button>
              <motion.button
                className="w-10 h-10 rounded-full flex items-center justify-center"
                onClick={() => setActiveTestimonial((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1))}
                whileHover={{ backgroundColor: "rgba(154, 140, 152, 0.1)" }}
                transition={{ duration: 0.3 }}
              >
                <span className="w-2.5 h-2.5 border-t-2 border-r-2 border-accent transform rotate-45 translate-x-[-0.5px]"></span>
              </motion.button>
            </div>
          </div>
        </div>
      </section>

      {/* Offer Section */}
      <section id="offer" className="py-32 text-white relative">
        <motion.div
          className="absolute inset-0 z-0"
          style={{
            background:
              "linear-gradient(to bottom, rgba(0, 0, 0, 0.9), rgba(0, 0, 0, 0.8)), url('https://images.unsplash.com/photo-1516979187457-637abb4f9353?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80') center/cover no-repeat",
          }}
          initial={{ scale: 1.1 }}
          whileInView={{ scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.5 }}
        />

        <motion.div
          className="absolute inset-0 z-0"
          style={{
            background: "radial-gradient(circle at 30% 70%, rgba(154, 140, 152, 0.2) 0%, transparent 70%)",
          }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
        />

        <div className="max-w-7xl mx-auto px-6 text-center relative z-10">
          <motion.h2
            className="font-serif text-4xl mb-16 relative"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            Begin Your Journey
            <motion.span
              className="absolute bottom-0 left-1/2 h-0.5 bg-accent"
              initial={{ width: "60px", x: "-50%" }}
              whileInView={{ width: "100px", x: "-50%" }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
            />
          </motion.h2>

          <motion.div
            className="bg-white bg-opacity-95 max-w-lg mx-auto p-16 text-black rounded relative"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <motion.div
              className="absolute top-0 left-0 w-full h-1 bg-accent"
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            />

            <p className="text-lg mb-5">The complete guide to understanding the psychology of connection</p>

            <motion.div
              className="text-5xl font-bold text-accent-dark my-8 relative inline-block"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.3 }}
            >
              £37
              <motion.span
                className="absolute -inset-5 border border-accent opacity-30"
                whileHover={{ scale: 1.1, opacity: 0.5 }}
                transition={{ duration: 0.3 }}
              />
            </motion.div>

            <p className="mb-6">One-time payment. Immediate access.</p>

            <motion.a
              href="https://buy.stripe.com/test_8wM4ij1SW7fRc2A289"
              className="inline-block bg-black text-white px-10 py-4 font-semibold text-lg rounded border border-black relative overflow-hidden"
              whileHover={{ borderColor: "var(--accent)" }}
              whileTap={{ scale: 0.98 }}
            >
              <motion.span
                className="absolute inset-0 bg-accent"
                initial={{ x: "-100%" }}
                whileHover={{ x: 0 }}
                transition={{ duration: 0.3 }}
                style={{ zIndex: -1 }}
              />
              Get the Book
            </motion.a>
          </motion.div>
        </div>
      </section>
    </>
  )
}

// Policy Pages
function PrivacyPolicy({ onBack }: { onBack: () => void }) {
  return (
    <section className="py-40 bg-white">
      <div className="max-w-4xl mx-auto px-6">
        <motion.div
          className="bg-white p-10 md:p-16 rounded shadow-md"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <motion.h1
            className="font-serif text-4xl mb-6 text-accent-dark text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Privacy Policy
          </motion.h1>

          <motion.p
            className="text-center mb-10 text-gray-500"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Last updated: June 2023
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <p className="mb-6">
              This Privacy Policy describes how your personal information is collected, used, and shared when you visit
              or make a purchase from our website.
            </p>

            <h2 className="font-serif text-2xl mt-10 mb-4 text-accent-dark">Information We Collect</h2>
            <p className="mb-4">
              When you visit the Site, we automatically collect certain information about your device, including
              information about your web browser, IP address, time zone, and some of the cookies that are installed on
              your device.
            </p>
            <p className="mb-6">
              Additionally, as you browse the Site, we collect information about the individual web pages or products
              that you view, what websites or search terms referred you to the Site, and information about how you
              interact with the Site.
            </p>

            <h2 className="font-serif text-2xl mt-10 mb-4 text-accent-dark">How We Use Your Information</h2>
            <p className="mb-4">We use the information we collect to:</p>
            <ul className="list-disc pl-6 mb-6 space-y-2">
              <li>Provide and maintain our service</li>
              <li>Notify you about changes to our service</li>
              <li>Allow you to participate in interactive features of our service</li>
              <li>Provide customer support</li>
              <li>Gather analysis or valuable information so that we can improve our service</li>
              <li>Monitor the usage of our service</li>
              <li>Detect, prevent and address technical issues</li>
            </ul>

            <h2 className="font-serif text-2xl mt-10 mb-4 text-accent-dark">Sharing Your Personal Information</h2>
            <p className="mb-6">
              We share your Personal Information with third parties to help us use your Personal Information, as
              described above. For example, we use Stripe to power our online store.
            </p>

            <h2 className="font-serif text-2xl mt-10 mb-4 text-accent-dark">Changes</h2>
            <p className="mb-6">
              We may update this privacy policy from time to time in order to reflect, for example, changes to our
              practices or for other operational, legal or regulatory reasons.
            </p>

            <h2 className="font-serif text-2xl mt-10 mb-4 text-accent-dark">Contact Us</h2>
            <p className="mb-10">
              For more information about our privacy practices, if you have questions, or if you would like to make a
              complaint, please contact us by email at privacy@7darkarts.com.
            </p>

            <div className="text-center mt-10">
              <motion.button
                onClick={onBack}
                className="text-accent font-semibold relative pl-6"
                whileHover={{ color: "var(--accent-dark)", paddingLeft: "30px" }}
                transition={{ duration: 0.3 }}
              >
                <span className="absolute left-0 transition-transform duration-300">←</span>
                Back to Home
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

function TermsOfService({ onBack }: { onBack: () => void }) {
  return (
    <section className="py-40 bg-white">
      <div className="max-w-4xl mx-auto px-6">
        <motion.div
          className="bg-white p-10 md:p-16 rounded shadow-md"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <motion.h1
            className="font-serif text-4xl mb-6 text-accent-dark text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Terms of Service
          </motion.h1>

          <motion.p
            className="text-center mb-10 text-gray-500"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Last updated: June 2023
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <h2 className="font-serif text-2xl mt-6 mb-4 text-accent-dark">1. Introduction</h2>
            <p className="mb-6">
              These Terms of Service govern your use of our website located at 7darkarts.com operated by 7 Dark Arts
              Publishing.
            </p>

            <h2 className="font-serif text-2xl mt-10 mb-4 text-accent-dark">2. Intellectual Property Rights</h2>
            <p className="mb-6">
              The content on the Site, including without limitation, the text, software, scripts, graphics, photos,
              sounds, music, videos, interactive features and the like ("Content") and the trademarks, service marks and
              logos contained therein ("Marks"), are owned by or licensed to 7 Dark Arts Publishing, subject to
              copyright and other intellectual property rights under the law.
            </p>

            <h2 className="font-serif text-2xl mt-10 mb-4 text-accent-dark">3. User Representations</h2>
            <p className="mb-4">By using the Site, you represent and warrant that:</p>
            <ul className="list-disc pl-6 mb-6 space-y-2">
              <li>All registration information you submit is truthful and accurate</li>
              <li>You will maintain the accuracy of such information</li>
              <li>Your use of the Site does not violate any applicable law or regulation</li>
            </ul>

            <h2 className="font-serif text-2xl mt-10 mb-4 text-accent-dark">4. Prohibited Activities</h2>
            <p className="mb-6">
              You may not access or use the Site for any purpose other than that for which we make the Site available.
              The Site may not be used in connection with any commercial endeavors except those that are specifically
              endorsed or approved by us.
            </p>

            <h2 className="font-serif text-2xl mt-10 mb-4 text-accent-dark">5. Purchases</h2>
            <p className="mb-6">
              All purchases through our site or other transactions for the sale of goods formed through the Site or as a
              result of visits made by you are governed by our Terms of Sale, which are hereby incorporated into these
              Terms of Service.
            </p>

            <h2 className="font-serif text-2xl mt-10 mb-4 text-accent-dark">6. Governing Law</h2>
            <p className="mb-10">
              These Terms shall be governed and construed in accordance with the laws of the United Kingdom, without
              regard to its conflict of law provisions.
            </p>

            <div className="text-center mt-10">
              <motion.button
                onClick={onBack}
                className="text-accent font-semibold relative pl-6"
                whileHover={{ color: "var(--accent-dark)", paddingLeft: "30px" }}
                transition={{ duration: 0.3 }}
              >
                <span className="absolute left-0 transition-transform duration-300">←</span>
                Back to Home
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

function Contact({ onBack }: { onBack: () => void }) {
  return (
    <section className="py-40 bg-white">
      <div className="max-w-4xl mx-auto px-6">
        <motion.div
          className="bg-white p-10 md:p-16 rounded shadow-md text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <motion.h1
            className="font-serif text-4xl mb-10 text-accent-dark"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Contact Us
          </motion.h1>

          <motion.p
            className="mb-8 text-lg"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            For customer support, please email us at:
          </motion.p>

          <motion.a
            href="mailto:support@7darkarts.com"
            className="text-2xl md:text-3xl text-accent-dark inline-block border-b-2 border-accent-light pb-2 mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            whileHover={{ color: "var(--accent)", borderBottomColor: "var(--accent)" }}
          >
            support@7darkarts.com
          </motion.a>

          <motion.p
            className="mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            We typically respond within 24-48 hours.
          </motion.p>

          <motion.button
            onClick={onBack}
            className="text-accent font-semibold relative pl-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            whileHover={{ color: "var(--accent-dark)", paddingLeft: "30px" }}
          >
            <span className="absolute left-0 transition-transform duration-300">←</span>
            Back to Home
          </motion.button>
        </motion.div>
      </div>
    </section>
  )
}

// Flame Animation Component
function FlameAnimation() {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div
      className="mt-12 inline-block"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ scale: 1.1 }}
      transition={{ duration: 0.5 }}
    >
      <motion.svg
        width="80"
        height="100"
        viewBox="0 0 80 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        animate={{
          filter: isHovered
            ? "drop-shadow(0 0 8px rgba(255, 255, 255, 0.8))"
            : "drop-shadow(0 0 2px rgba(255, 255, 255, 0.3))",
        }}
        transition={{ duration: 0.5 }}
      >
        <motion.path
          d="M40 0C40 0 50 20 50 40C50 50 45 55 40 55C35 55 30 50 30 40C30 20 40 0 40 0Z"
          fill="white"
          animate={{
            d: isHovered
              ? "M40 0C40 0 55 20 55 40C55 55 45 60 40 60C35 60 25 55 25 40C25 20 40 0 40 0Z"
              : "M40 0C40 0 50 20 50 40C50 50 45 55 40 55C35 55 30 50 30 40C30 20 40 0 40 0Z",
          }}
          transition={{
            duration: 0.8,
            ease: "easeInOut",
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
        />
        <motion.path
          d="M25 40C25 40 35 50 40 70C45 50 55 40 55 40C55 60 45 80 40 100C35 80 25 60 25 40Z"
          fill="white"
          animate={{
            d: isHovered
              ? "M20 40C20 40 35 50 40 75C45 50 60 40 60 40C60 65 45 85 40 100C35 85 20 65 20 40Z"
              : "M25 40C25 40 35 50 40 70C45 50 55 40 55 40C55 60 45 80 40 100C35 80 25 60 25 40Z",
          }}
          transition={{
            duration: 1,
            ease: "easeInOut",
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
            repeatDelay: 0.2,
          }}
        />
        <motion.path
          d="M30 70C30 70 35 75 40 85C45 75 50 70 50 70C50 80 45 90 40 100C35 90 30 80 30 70Z"
          fill="rgba(154, 140, 152, 0.8)"
          animate={{
            d: isHovered
              ? "M25 70C25 70 35 75 40 90C45 75 55 70 55 70C55 85 45 95 40 100C35 95 25 85 25 70Z"
              : "M30 70C30 70 35 75 40 85C45 75 50 70 50 70C50 80 45 90 40 100C35 90 30 80 30 70Z",
            fill: isHovered ? "rgba(154, 140, 152, 1)" : "rgba(154, 140, 152, 0.8)",
          }}
          transition={{
            duration: 1.2,
            ease: "easeInOut",
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
            repeatDelay: 0.3,
          }}
        />
      </motion.svg>
    </motion.div>
  )
}

// Chapter Card Component
function ChapterCard({ chapter, index }: { chapter: Chapter; index: number }) {
  return (
    <motion.div
      className="bg-white p-8 rounded relative overflow-hidden border border-transparent"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{
        y: -10,
        boxShadow: "var(--shadow-lg)",
        borderColor: "rgba(0, 0, 0, 0.05)",
      }}
    >
      <motion.div
        className="absolute top-0 left-0 w-1 h-0 bg-accent"
        whileHover={{ height: "100%" }}
        transition={{ duration: 0.3 }}
      />

      <span className="inline-block font-semibold mb-4 text-accent relative pl-5">
        <span className="absolute top-1/2 left-0 w-3 h-px bg-accent"></span>
        Chapter {index + 1}
      </span>

      <h3 className="text-2xl font-serif mb-4">{chapter.title}</h3>
      <p className="text-dark-gray leading-relaxed">{chapter.description}</p>
    </motion.div>
  )
}

// Data
const chapters: Chapter[] = [
  {
    title: "The Push-Pull Dynamic",
    description:
      "How alternating attention creates lasting fascination and why the human mind responds to patterns of availability.",
  },
  {
    title: "Strategic Generosity",
    description:
      "The psychology behind giving and how to create meaningful connections through thoughtful interaction.",
  },
  {
    title: "Mirroring Mastery",
    description: "How to build instant rapport by understanding and reflecting someone's communication style.",
  },
  {
    title: "Emotional Resonance",
    description: "Creating deep bonds by becoming the missing piece in someone's emotional puzzle.",
  },
  {
    title: "The Craving Principle",
    description: "Transform from a person into an experience that lingers in the mind.",
  },
  {
    title: "Reverse Psychology",
    description: "Harness the power of autonomy to make others feel they're choosing freely.",
  },
  {
    title: "The Art of Absence",
    description: "Understanding the psychological impact of presence and absence in human relationships.",
  },
]

const testimonials = [
  {
    text: "This book gave me insights into human behavior that I've never encountered elsewhere. It's changed how I approach all my relationships.",
    author: "— Michael, London",
  },
  {
    text: "The psychological depth is remarkable. I find myself noticing patterns in interactions that I never saw before.",
    author: "— Sarah, New York",
  },
  {
    text: "Not what I expected—much more sophisticated. This isn't about tricks, but about understanding fundamental human psychology.",
    author: "— David, Berlin",
  },
  {
    text: "I've read many books on psychology and human behavior, but this one stands out for its practical insights and ethical approach.",
    author: "— Emma, Sydney",
  },
]

// Types
interface Chapter {
  title: string
  description: string
}
