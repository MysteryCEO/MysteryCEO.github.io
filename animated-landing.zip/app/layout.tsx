import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Inter, Libre_Baskerville } from "next/font/google"

// Load Inter font
const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
  weight: ["300", "400", "500", "600", "700"],
})

// Load Libre Baskerville font
const libreBaskerville = Libre_Baskerville({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-libre-baskerville",
  weight: ["400", "700"],
})

export const metadata: Metadata = {
  title: "The 7 Dark Arts of Seduction | Psychological Mastery",
  description: "Master the psychology of connection with The 7 Dark Arts of Seduction",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${libreBaskerville.variable}`}>
      <body className={inter.className}>{children}</body>
    </html>
  )
}
