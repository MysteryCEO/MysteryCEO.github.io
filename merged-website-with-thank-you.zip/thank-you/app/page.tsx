"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Check, Download, Flame } from "lucide-react"
import Link from "next/link"

export default function ThankYouPage() {
  const [loaded, setLoaded] = useState(false)
  const [showContent, setShowContent] = useState(false)
  const [downloadHovered, setDownloadHovered] = useState(false)

  useEffect(() => {
    // Simulate checking payment status
    const urlParams = new URLSearchParams(window.location.search)
    const paymentSuccess = urlParams.get("payment")

    // Animation sequence
    const timer1 = setTimeout(() => setLoaded(true), 800)
    const timer2 = setTimeout(() => setShowContent(true), 1600)

    return () => {
      clearTimeout(timer1)
      clearTimeout(timer2)
    }
  }, [])

  return (
    <div className="min-h-screen bg-[#0f0d1f] text-white flex flex-col overflow-hidden relative">
      {/* Animated background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0f0d1f] to-[#1a1730] opacity-80" />

      {/* Animated particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-[#f5f5f5] opacity-20"
            initial={{
              x: Math.random() * 100 + "%",
              y: -10,
              opacity: 0.1 + Math.random() * 0.3,
            }}
            animate={{
              y: "120vh",
              opacity: 0,
            }}
            transition={{
              duration: 10 + Math.random() * 20,
              repeat: Number.POSITIVE_INFINITY,
              delay: Math.random() * 5,
              ease: "linear",
            }}
          />
        ))}
      </div>

      {/* Initial loading animation */}
      <AnimatePresence>
        {!loaded && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-[#0f0d1f]"
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 1.2, opacity: 0 }}
              transition={{ duration: 0.6 }}
            >
              <Flame className="w-16 h-16 text-[#f5f5f5]" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main content */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 py-20 z-10">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: loaded ? 1 : 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="max-w-md w-full mx-auto"
        >
          <div className="text-center mb-8">
            <motion.div
              className="inline-block"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: loaded ? 0 : 20, opacity: loaded ? 1 : 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-[#9a8c98] to-[#4a4e69] flex items-center justify-center">
                <Check className="w-10 h-10" />
              </div>
            </motion.div>

            <motion.h1
              className="text-3xl md:text-4xl font-serif font-bold mb-4"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: loaded ? 0 : 20, opacity: loaded ? 1 : 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              Your Order Is Complete
            </motion.h1>
          </div>

          <AnimatePresence>
            {showContent && (
              <motion.div
                className="space-y-8"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                <motion.div
                  className="p-8 rounded-lg border border-[#9a8c98]/20 bg-[#1a1730]/50 backdrop-blur-sm"
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.6, delay: 0.7 }}
                >
                  <p className="mb-4 text-[#f5f5f5]/90">
                    Thank you for purchasing <strong>The 7 Dark Arts of Seduction - Expanded Premium Edition</strong>.
                  </p>
                  <p className="text-[#f5f5f5]/80 mb-6">
                    Below you'll find your download link. This book will change how you see human connection forever.
                  </p>

                  <motion.div className="relative" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    <Link
                      href="/The_7_Dark_Arts_of_Seduction.pdf"
                      download="The_7_Dark_Arts_of_Seduction.pdf"
                      className="relative block w-full py-4 px-6 text-center font-medium rounded-md overflow-hidden group"
                      onMouseEnter={() => setDownloadHovered(true)}
                      onMouseLeave={() => setDownloadHovered(false)}
                    >
                      <motion.div
                        className="absolute inset-0 bg-gradient-to-r from-[#9a8c98] to-[#4a4e69]"
                        initial={{ x: "-100%" }}
                        animate={{ x: downloadHovered ? "0%" : "-100%" }}
                        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                      />
                      <motion.div
                        className="absolute inset-0 bg-[#f5f5f5]/10"
                        initial={{ opacity: 1 }}
                        animate={{ opacity: downloadHovered ? 0 : 1 }}
                        transition={{ duration: 0.3 }}
                      />
                      <span className="relative flex items-center justify-center gap-2">
                        <Download className="w-5 h-5" />
                        Download Your Book
                      </span>
                    </Link>
                  </motion.div>
                </motion.div>

                <motion.div
                  className="p-6 rounded-lg bg-[#9a8c98]/10 relative"
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.6, delay: 0.9 }}
                >
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-[#9a8c98] text-[#0f0d1f] text-xs font-bold px-3 py-1 rounded-full">
                    Bonus
                  </div>
                  <p className="text-[#f5f5f5]/80 text-sm">
                    <strong>Bonus:</strong> Keep this link safe. You'll receive future updates and exclusive content as
                    part of your premium purchase.
                  </p>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </main>
    </div>
  )
}
